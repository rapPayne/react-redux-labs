This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Marvel Superhero lookup
A demo application create for the lovely folks at JPMC in response to requests to see Redux, Ajax, stateful and stateless components and other stuff we didn't have time for in merely 3 days.

## To run
Go to http://marvel.com and get yourself an API key. It is free and easy. Once you get that key, open store.js and put it in the apiKey constant.

Then,
`npm install`
`npm start`

Enjoy!



