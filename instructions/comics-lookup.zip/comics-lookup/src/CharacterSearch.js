import React, { Component } from 'react';
import { store } from './store/store';
import { CharacterCard } from './CharacterCard';

export class CharacterSearch extends Component {
  constructor(props) {
    super(props);
    this.state = { theCharacter: props.theCharacter, characterName: props.theCharacter.name };
  }

  static getDerivedStateFromProps(newProps, oldState, p3) {
    return { theCharacter: newProps.theCharacter };
  }
  render() {
    return (
      <>
        <div className="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
          <input value={this.state.characterName} onChange={this.handleChange} className="mdl-textfield__input" id="characterName" />
          <label className="mdl-textfield__label" htmlFor="characterName">Character name</label>
        </div>
        <div>
          <button onClick={e => this.getCharacter(this.state.characterName)} className="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent">Search</button>
        </div>
        <CharacterCard character={this.state.theCharacter} />
      </>
    )
  }

  handleChange = (evt) => {
    this.setState({ characterName: evt.target.value });
  }

  getCharacter(characterName) {
    store.dispatch({ type: "FETCH_CHARACTER", theCharacter: characterName });
  }
}