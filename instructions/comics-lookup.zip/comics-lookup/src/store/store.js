import { createStore, applyMiddleware } from 'redux';

const apiKey = "";

const reducer = (state, action) => {
  if (!action) return state;
  switch (action.type) {
    case "SET_CHARACTER":
      return { ...state, theCharacter: action.theCharacter };
    default:
      return state;
  }
}
const initialState = { theCharacter: { name: "" } };

const fetchCharacterMiddleware = ({ dispatch, getState }) => next => action => {
  if (action.type === "FETCH_CHARACTER") {
    const { theCharacter } = action;
    const url = `https://gateway.marvel.com/v1/public/characters?name=${theCharacter}&apikey=${apiKey}`;
    fetch(url)
      .then(res => res.json())
      .then(res => res.data.results[0])
      .then(res => { console.log("Fetch:", res); return res })
      .then(res => dispatch({ type: "SET_CHARACTER", theCharacter: res }))
      .catch(err => console.error(`Error fetching ${url}`, err))
  }

  next(action);
}

const enhancers = applyMiddleware(fetchCharacterMiddleware);

export const store = createStore(reducer, initialState, enhancers);