import React, { Component } from 'react';
import 'material-design-lite/material.css';
import 'material-design-lite/material';
import './App.css';
import { CharacterSearch } from './CharacterSearch';
import { store } from './store/store';

class App extends Component {
  constructor() {
    super();
    store.subscribe(() => {
      this.setState(store.getState());
    })
    this.state=store.getState();
  }
  render() {
    return (
      <div>
        <header>
        </header>
        <main>
          <h1>Marvel Comics Lookup</h1>
          <CharacterSearch theCharacter={this.state.theCharacter} />
        </main>
      </div>
    );
  }
}

export default App;
