import React from 'react';

export const NewsHome = (props) => {
  const styles = {
    img: {
      maxWidth: "90%",
    }
  }
  return (
    <>
      <h1>Today's top stories</h1>
      <h2>{props.title}</h2>
      {props.articles.map((x,idx) => {
        return (
          <section key={idx}>
            <h2>{x.title}</h2>
            <span>{x.author}</span>
            <p>{x.description}</p>
            <img src={x.urlToImage} style={styles.img} alt="" />
          </section>
        )
      })
      }
    </>
  )
}