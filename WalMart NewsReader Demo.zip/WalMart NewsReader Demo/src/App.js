import React, { Component } from 'react';
import './App.css';
import { store } from './reduxStuff/store';
import { NewsHome } from './NewsHome';

class App extends Component {
  constructor() {
    super();
    this.state = store.getState();
    store.subscribe(this.redraw);
  }
  componentDidMount() {
    store.dispatch({type:"FETCH_ARTICLES"});
  }
  render() {
    return (
      <div>
        <header>
        </header>
        <button onClick={() => store.dispatch({type:"FETCH_ARTICLES"})}>Get new articles</button>
        <NewsHome articles={this.state.articles} />
      </div>
    );
  }

  redraw = () => {
    this.setState(store.getState());
  }
}

export default App;
