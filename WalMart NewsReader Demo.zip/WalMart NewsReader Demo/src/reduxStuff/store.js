import { createStore, applyMiddleware } from 'redux';
import { reducer } from './reducers';
import { fetchNewsMiddleware } from './middleware';

const initialState = {
  "status": "ok",
  "totalResults": 36,
  "articles": [
  {
  "source": {
  "id": "cnn",
  "name": "CNN"
  },
  "author": "Charles Riley, CNN Business",
  "title": "Doors are slamming shut for Huawei in Europe - CNN",
  "description": "Huawei is coming under pressure in two more key European markets.",
  "url": "https://www.cnn.com/2018/12/14/business/huawei-deutsche-telekom-orange/index.html",
  "urlToImage": "https://cdn.cnn.com/cnnnext/dam/assets/181214120156-huawei-0327-restricted-super-tease.jpg",
  "publishedAt": "2018-12-14T18:25:00Z",
  "content": null
  },
  {
  "source": {
  "id": "the-new-york-times",
  "name": "The New York Times"
  },
  "author": null,
  "title": "Wisconsin’s Scott Walker Signs Bills Stripping Powers From Incoming Governor - The New York Times",
  "description": "Mr. Walker, a Republican who has pushed Wisconsin to the right, signed legislation hobbling his Democratic successor as one of his final acts as governor.",
  "url": "https://www.nytimes.com/2018/12/14/us/wisconsin-governor-scott-walker.html",
  "urlToImage": "https://static01.nyt.com/images/2018/12/13/us/00walker-01/00walker-01-facebookJumbo.jpg",
  "publishedAt": "2018-12-14T18:22:30Z",
  "content": "In recent days, Mr. Walker has spoken again and again of his legacy. He posted 21 tweets in 25 minutes, each starting with OUR LEGACY and listing an accomplishment. Facing angry accusations on Facebook, he wrote that our real legacy was job growth. And in a s… [+1996 chars]"
  },
]};

const enhancers = applyMiddleware(fetchNewsMiddleware);

export const store = createStore(reducer, initialState, enhancers)