
export const reducer = (state, action) => {
  const newState = { ...state };
  if (!action) return state;
  switch (action.type) {
    case "SET_ARTICLES":
      // DO STUFF
      return { ...state, articles: action.articles };
    default:
      return state;
  }
  return newState;
};