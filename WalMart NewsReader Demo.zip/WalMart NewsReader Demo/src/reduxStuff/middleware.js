
export const fetchNewsMiddleware = ({getState, dispatch}) => next => action => {
  console.log(action);
  if (action.type === "FETCH_ARTICLES") {
    const key = "7a78cc5c25f1499fb2092e462d7694a8";
    const url = `https://newsapi.org/v2/top-headlines?country=us&apiKey=${key}`
    console.log("Pretending to get articles here");
    fetch(url)
    .then(res => res.json())
    .then(res => dispatch({type:"SET_ARTICLES",articles: res.articles}))
    
  }
  next(action);
}