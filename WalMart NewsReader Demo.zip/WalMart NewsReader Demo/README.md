# News Demo

For the awesome folks at WalMart as a React/Redux demo of making Ajax calls via middleware in Redux.

Enjoy!

Rap
