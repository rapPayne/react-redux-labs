# A news reader
The demonstration we did in Redux/React class on September 27-28, 2018.

## To run
1. Go to http://newsapi.org
1. Register for an api key. 
1. Edit middleware.js and put in your api key. 
1. cd to the root
1. Run npm install
1. Run npm start
